import 'package:cloud_firestore/cloud_firestore.dart';

class UserService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<Map<String, dynamic>> getUserData(String userId) async {
    final userDoc = _firestore.collection('user').doc(userId);
    final userSnapshot = await userDoc.get();
    return userSnapshot.data()!;
  }
}
