import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class PatientProfileScreen extends StatefulWidget {
  final String userId; // Accept user ID to fetch data

  const PatientProfileScreen({Key? key, required this.userId}) : super(key: key);

  @override
  _PatientProfileScreenState createState() => _PatientProfileScreenState();
}

class _PatientProfileScreenState extends State<PatientProfileScreen> {
  late Future<Map<String, dynamic>> _userData;

  @override
  void initState() {
    super.initState();
    // Print the userId to check if it's being passed correctly
    print('Passed userId: ${widget.userId}');

    _userData = getUserData(widget.userId);
  }

  Future<Map<String, dynamic>> getUserData(String userId) async {
    try {
      print('Fetching data for userId: $userId');
      final userDoc = FirebaseFirestore.instance.collection('users').doc(userId);
      print('Document path: users/$userId'); // Add this line for debugging

      final userSnapshot = await userDoc.get();

      if (userSnapshot.exists) {
        print('User data: ${userSnapshot.data()}');  // Print fetched data
        return userSnapshot.data()!;
      } else {
        print('No user found for userId: $userId');  // Notify if user not found
        throw Exception('User not found');
      }
    } catch (e) {
      print('Error fetching user data: $e');
      throw Exception('Failed to load user data: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Patient Profile'),
        backgroundColor: Colors.teal,
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _userData,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (!snapshot.hasData) {
            return const Center(child: Text('No data found'));
          }

          final userData = snapshot.data!;
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Profile Header
                Center(
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 60,
                        backgroundImage: userData['profilePicture'] != null
                            ? NetworkImage(userData['profilePicture'])
                            : const AssetImage('assets/images/profile.jpg') as ImageProvider,
                      ),
                      const SizedBox(height: 10),
                      Text(
                        userData['name'] ?? 'Unknown',
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        'Age: ${userData['age'] ?? 'N/A'}',
                        style: const TextStyle(fontSize: 18, color: Colors.grey),
                      ),
                      Text(
                        'Gender: ${userData['gender'] ?? 'N/A'}',
                        style: const TextStyle(fontSize: 18, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // Health Metrics Card
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  elevation: 5,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Health Metrics',
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        const Divider(),
                        ListTile(
                          leading: const Icon(Icons.favorite, color: Colors.red),
                          title: const Text('Blood Pressure'),
                          subtitle: Text(userData['bloodPressure'] ?? 'N/A'),
                        ),
                        ListTile(
                          leading: const Icon(Icons.monitor_heart, color: Colors.blue),
                          title: const Text('Heart Rate'),
                          subtitle: Text(userData['heartRate'] ?? 'N/A'),
                        ),
                        ListTile(
                          leading: const Icon(Icons.scale, color: Colors.orange),
                          title: const Text('Height'),
                          subtitle: Text('${userData['height'] ?? 'N/A'} cm'),
                        ),
                        ListTile(
                          leading: const Icon(Icons.straighten, color: Colors.green),
                          title: const Text('Weight'),
                          subtitle: Text('${userData['weight'] ?? 'N/A'} kg'),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // Disease Information Card
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  elevation: 5,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Disease Information',
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        const Divider(),
                        Text(userData['disease'] ?? 'N/A'),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // Treatment Plans Card
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  elevation: 5,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Treatment Plans',
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        const Divider(),
                        Text(userData['treatmentPlans'] ?? 'N/A'),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
