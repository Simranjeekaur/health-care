import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:healthcare/communitysupport_screen.dart';
import 'package:healthcare/dailyhealthtips_screen.dart';
import 'package:healthcare/patientprofile_screen.dart'; // Ensure this import path is correct
import 'package:healthcare/userform_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Retrieve the current user
    User? user = FirebaseAuth.instance.currentUser;
    String userId = user?.uid ?? ''; // Get the user ID

    return Scaffold(
      body: Column(
        children: [
          // Top Navigation Bar
          Container(
            color: Colors.teal,
            padding: EdgeInsets.symmetric(vertical: 10.0),
            child: Column(
              children: [
                SizedBox(height: 10), // Space above the icons
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    IconButton(
                      icon: Icon(Icons.home, size: 30),
                      color: Colors.white,
                      onPressed: () {
                        // Handle home icon press
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.search, size: 30),
                      color: Colors.white,
                      onPressed: () {
                        // Handle search icon press
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.notifications, size: 30),
                      color: Colors.white,
                      onPressed: () {
                        // Handle notifications icon press
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.person, size: 30),
                      color: Colors.white,
                      onPressed: () {
                        // Handle profile icon press
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 20),
                  // Patient Profile Card
                  Card(
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    margin: EdgeInsets.only(bottom: 16.0),
                    child: ListTile(
                      contentPadding: EdgeInsets.all(16.0),
                      leading: CircleAvatar(
                        radius: 30,
                        backgroundImage: AssetImage('assets/images/profile_picture.jpg'),
                      ),
                      title: Text(
                        'Patient Profile',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text('View and edit your profile'),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PatientProfileScreen(userId: userId),
                          ),
                        );
                      },
                    ),
                  ),
                  // Daily Health Tips Card
                  Card(
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    margin: EdgeInsets.only(bottom: 16.0),
                    child: ListTile(
                      contentPadding: EdgeInsets.all(16.0),
                      leading: Icon(Icons.lightbulb_outline, size: 30, color: Colors.green),
                      title: Text(
                        'Daily Health Tips',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text('Remember to drink a glass of water today!'),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => DailyHealthTipsScreen(),
                          ),
                        );
                      },
                    ),
                  ),
                  // Community and Support Card
                  Card(
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    margin: EdgeInsets.only(bottom: 16.0),
                    child: ListTile(
                      contentPadding: EdgeInsets.all(16.0),
                      leading: Icon(Icons.group, size: 30, color: Colors.purple),
                      title: Text(
                        'Community and Support',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text('Join a support group or access educational resources'),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => CommunitySupportScreen(),
                          ),
                        );
                      },
                    ),
                  ),
                  // Treatment Plans Card
                  Card(
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    margin: EdgeInsets.only(bottom: 16.0),
                    child: ListTile(
                      contentPadding: EdgeInsets.all(16.0),
                      leading: Icon(Icons.assignment, size: 30, color: Colors.orange),
                      title: Text(
                        'Treatment Plans',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text('View ongoing treatment plans and personalized exercise programs'),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => UserFormScreen(),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
