package io.flutter.plugins;

public @interface NonNull {
}
