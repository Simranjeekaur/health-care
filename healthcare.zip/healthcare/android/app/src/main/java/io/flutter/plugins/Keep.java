package io.flutter.plugins;

public @interface Keep {
}
